/*
SQLyog Ultimate v13.1.1 (64 bit)
MySQL - 5.5.16 : Database - ads
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`ads` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `ads`;

/*Table structure for table `migrations` */

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `migrations` */

insert  into `migrations`(`id`,`migration`,`batch`) values 
(1,'2014_10_12_000000_create_users_table',1),
(2,'2014_10_12_100000_create_password_resets_table',1);

/*Table structure for table `password_resets` */

DROP TABLE IF EXISTS `password_resets`;

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `password_resets` */

/*Table structure for table `tbl_ads` */

DROP TABLE IF EXISTS `tbl_ads`;

CREATE TABLE `tbl_ads` (
  `ads_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary key',
  `ads_name` varchar(255) NOT NULL DEFAULT '',
  `ads_note` varchar(1024) DEFAULT NULL,
  `ads_content` longtext,
  `ads_uses` int(11) NOT NULL DEFAULT '0' COMMENT 'Ads clicked count',
  `ads_status` tinyint(4) NOT NULL DEFAULT '1',
  `ads_created_at` datetime DEFAULT NULL,
  `ads_updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`ads_id`),
  KEY `IDX_name` (`ads_name`),
  KEY `IDX_status` (`ads_status`),
  KEY `IDX_created_at` (`ads_created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='Ads (banner,...)';

/*Data for the table `tbl_ads` */

insert  into `tbl_ads`(`ads_id`,`ads_name`,`ads_note`,`ads_content`,`ads_uses`,`ads_status`,`ads_created_at`,`ads_updated_at`) values 
(1,'ads_001','Test ads 001',NULL,0,1,'2019-07-05 10:45:36','2019-07-05 10:45:36');

/*Table structure for table `tbl_rel` */

DROP TABLE IF EXISTS `tbl_rel`;

CREATE TABLE `tbl_rel` (
  `rel_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary key',
  `rel_type` varchar(25) NOT NULL,
  `rel_ref01` varchar(25) DEFAULT NULL,
  `rel_ref02` varchar(25) DEFAULT NULL,
  `rel_created_at` datetime DEFAULT NULL,
  `rel_updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`rel_id`),
  UNIQUE KEY `UNIQ_01` (`rel_type`,`rel_ref01`,`rel_ref02`),
  KEY `IDX_ref01` (`rel_ref01`),
  KEY `IDX_ref02` (`rel_ref02`),
  KEY `IDX_created_at` (`rel_created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Relationships.';

/*Data for the table `tbl_rel` */

/*Table structure for table `tbl_rpt` */

DROP TABLE IF EXISTS `tbl_rpt`;

CREATE TABLE `tbl_rpt` (
  `rpt_int` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary key',
  `rpt_ads_id` int(11) DEFAULT NULL,
  `rpt_ua` varchar(1024) DEFAULT NULL COMMENT 'User agent',
  `rpt_ipv4` varchar(100) DEFAULT NULL,
  `rpt_ipv6` varchar(255) DEFAULT NULL,
  `rpt_browser` varchar(15) DEFAULT NULL,
  `rpt_platform` varchar(15) DEFAULT NULL,
  `rpt_extra` text,
  `rpt_created_at` datetime DEFAULT NULL,
  `rpt_updateed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`rpt_int`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Report.';

/*Data for the table `tbl_rpt` */

/*Table structure for table `tbl_tag` */

DROP TABLE IF EXISTS `tbl_tag`;

CREATE TABLE `tbl_tag` (
  `tag_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary key',
  `tag_type` varchar(25) DEFAULT NULL,
  `tag_name` varchar(255) NOT NULL DEFAULT '',
  `tag_note` varchar(1024) DEFAULT NULL,
  `tag_uses` int(11) NOT NULL DEFAULT '0',
  `tag_status` tinyint(4) NOT NULL DEFAULT '1' COMMENT 'on|off',
  `tag_created_at` datetime DEFAULT NULL,
  `tag_updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`tag_id`),
  UNIQUE KEY `UNIQ_01` (`tag_name`,`tag_type`),
  KEY `IDX_type` (`tag_type`),
  KEY `IDX_created_at` (`tag_created_at`),
  KEY `IDX_uses` (`tag_uses`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='Tags system.';

/*Data for the table `tbl_tag` */

insert  into `tbl_tag`(`tag_id`,`tag_type`,`tag_name`,`tag_note`,`tag_uses`,`tag_status`,`tag_created_at`,`tag_updated_at`) values 
(1,NULL,'tag_name_001','Test tag name 001',0,1,'2019-07-05 09:29:49','2019-07-05 09:29:49'),
(2,NULL,'tag_name_002','Test tag name 002',0,1,'2019-07-05 09:30:13','2019-07-05 09:30:13');

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/*Data for the table `users` */

insert  into `users`(`id`,`name`,`email`,`password`,`remember_token`,`created_at`,`updated_at`) values 
(1,'Khanh-It','phikhanh.8x@gmail.com','$2y$10$r/aDi4S7Q3eZQyVOLOHY4ujoeBUi6Myp907N8Pfo60fzSscnTJlj6','kD9ZHuhVKQ4Ajc7E5XsbOIAuOWgFddcW1U4OagwUxDEzwSuUpq5WZyoqr1vF','2018-07-05 09:36:42','2018-07-05 09:36:42');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
